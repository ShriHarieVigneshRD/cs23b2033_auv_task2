// Auto-generated. Do not edit!

// (in-package bonus_pkg.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class node1message {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.message1 = null;
    }
    else {
      if (initObj.hasOwnProperty('message1')) {
        this.message1 = initObj.message1
      }
      else {
        this.message1 = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type node1message
    // Serialize message field [message1]
    bufferOffset = _serializer.string(obj.message1, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type node1message
    let len;
    let data = new node1message(null);
    // Deserialize message field [message1]
    data.message1 = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.message1);
    return length + 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'bonus_pkg/node1message';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '4ddbec3385cb4f20c6e5dbab2a4dca86';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string message1
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new node1message(null);
    if (msg.message1 !== undefined) {
      resolved.message1 = msg.message1;
    }
    else {
      resolved.message1 = ''
    }

    return resolved;
    }
};

module.exports = node1message;
