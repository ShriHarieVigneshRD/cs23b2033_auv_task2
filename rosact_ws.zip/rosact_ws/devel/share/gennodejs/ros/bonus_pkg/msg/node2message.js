// Auto-generated. Do not edit!

// (in-package bonus_pkg.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class node2message {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.message2 = null;
    }
    else {
      if (initObj.hasOwnProperty('message2')) {
        this.message2 = initObj.message2
      }
      else {
        this.message2 = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type node2message
    // Serialize message field [message2]
    bufferOffset = _serializer.string(obj.message2, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type node2message
    let len;
    let data = new node2message(null);
    // Deserialize message field [message2]
    data.message2 = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.message2);
    return length + 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'bonus_pkg/node2message';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '5d38ea1ffc8497616107722c410a0b99';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string message2
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new node2message(null);
    if (msg.message2 !== undefined) {
      resolved.message2 = msg.message2;
    }
    else {
      resolved.message2 = ''
    }

    return resolved;
    }
};

module.exports = node2message;
