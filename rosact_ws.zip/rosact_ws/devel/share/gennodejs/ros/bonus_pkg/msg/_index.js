
"use strict";

let node2message = require('./node2message.js');
let node1message = require('./node1message.js');

module.exports = {
  node2message: node2message,
  node1message: node1message,
};
