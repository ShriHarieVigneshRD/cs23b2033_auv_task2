# AUV-ROS-IIITDM
<p>This repo contains all the required files for the hw from the AUV session on ROS.</p>
<p>Q1 -> (test1_pkg) : It is just a basic script , where we have 2 publishers and 2 subscribers.</p>
<p>Q2 -> (test2_pkg) : It is a script where we have only one node , which is both a publisher and a subscriber ( subscribed to itself ). On running the node using rosrun (run the code on the two different terminals) whatever message we type, we get the response (from the same program).</p>
<p>Q3 -> (bonus_pkg) : Exactly similar to Q2, but we have 2 nodes and the catch is that the subscriber (subscribed to itself) shouldn't display the message from the publisher which is itself.</p>

